# Implementation-spec bundle

Contains only files NOT in research_review_bundle.tar.gz (checked by path and sha256).

Source is from branch `staging` @ 1a0c8ac (clean tree).

## Requested source
- lares/core/policy_generation.py, lares/search/schemas.py, lares/search/archive.py
- scripts/summarise_experiments.py
- lares/fitting/optimizers.py, lares/fitting/objectives.py

## Tests (every test that imports the modules above, plus the contracts generation must satisfy)
- test_search.py: schemas, archive, feedback (unittest)
- test_training_pipeline.py, test_phase1_phase2.py: self-running scripts, not unittest
- test_two_phase_policy_generation.py: ideas -> implementation flow (unittest)
- test_fitting.py, test_objectives.py: optimizers and objectives (unittest)
- test_policy_interface.py: SymbolicPolicy/validator contract (unittest)
- test_generate_policy.py: NOT a test suite. It is the harness appended to LLM output and run as a subprocess.

## Generation-1 run artifacts (2026-09-13, gpt-5, 2 generations x 3 candidates, 843 s)
- logs/evolution_review_20260913/experiments/gen1_cand{0,1,2}.json: all three records (status rejected; screen success 0.000).
- logs/evolution_review_20260913/llm_evolution_transcript.gen1.log: the run header plus transcript lines 612-1313, which are exactly
  generation 1's four calls: policy_ideas, then policy_implement_0/1/2 (one per idea, in that order).
  The policy_ideas request's user message embeds gen_0/feedback.md (in research_review_bundle.tar.gz).
  Generation 0's calls (lines 7-611) are omitted.
- logs/evolution_review_20260913/gen_1/Iter_1_ideas.json: the parsed ideas. policy_implement_i produced gen1_cand<i>.
- Known gap: parent_ids, idea_id and proposal_id are empty in all three records, so the
  idea -> candidate mapping above comes from call order, not from the records.
- Config for the run: recovered/review_run.yaml in research_review_bundle.tar.gz.

## Transcript de-duplication
The generation-1 transcript quoted files already shipped in research_review_bundle.tar.gz. Each verbatim copy is
replaced by a marker `[[omitted: verbatim copy of <path> from research_review_bundle.tar.gz, <bytes>, sha256 <hex>]]`:
- logs/evolution_review_20260913/gen_0/feedback.md: 4 copies
- lares/utils/policy_prompts/new_code_output_tip.txt: 6 copies
- lares/utils/policy_prompts/code_feedback.txt: 4 copies
- lares/utils/policy_prompts/initial_system.txt: 3 copies
- lares/utils/policy_prompts/ideas_system.txt: 1 copy
Prompt text that appears only in filled-in form, not as a whole file, is left in place.
To restore the exact transcript, replace each marker with the JSON-string-escaped
(ensure_ascii=False, without the surrounding quotes) contents of that file from research_review_bundle.tar.gz.
