## Evidence from generation 0
All candidates were scored on the identical ordered case list `push-v2:development:s2000:n50#head10`, so differences between them are differences in the policy and not in which placements they drew.

### Population
candidate           success  progress  params  dead  dominant failure
---------------------------------------------------------------------
gen0_cand1            0.267    0.1129      15     2  stopped_short_of_goal
gen0_cand0            0.167    0.0629      15     1  never_reached_object
gen0_cand2            0.100    0.0257      17     4  never_reached_object

### The two most informative candidates, in full
These two are shown together because they differ behaviourally, not because both scored well. Compare them to work out which structural difference produced the difference in outcome.

#### Parent 1: gen0_cand1
  success 0.267 +- 0.082   mean return 256.2   over 30 cases
  failure labels: {'stopped_short_of_goal': 22, 'success': 8}
  final goal distance (m)    mean +0.1082   p25 +0.0518   p75 +0.1478
  signed goal progress (m)   mean +0.1129   p25 +0.1031   p75 +0.1370
  lateral drift (m)          mean +0.0336   p25 +0.0106   p75 +0.0421
  closest approach (m)       mean +0.0310   p25 +0.0297   p75 +0.0313
  object displacement (m)    mean +0.1309   p25 +0.1274   p75 +0.1383
  action saturation by axis: 0.00, 0.00, 0.00, 0.00
  gate occupancy above 0.5:
    align_err            occupancy 0.000   transitions 0.0   crossed in 0/30 episodes
    barrier              occupancy 0.018   transitions 0.4   crossed in 12/30 episodes
    push_gate            occupancy 0.000   transitions 0.0   crossed in 0/30 episodes
  parameters the executed action does NOT respond to: ['kv_damp', 'log_std']. These are dead weight; remove them or connect them to the action.
  before fitting: success 0.000, return 15.7. Fitting did not make it worse.
  fitting: train 0.06697 -> validation 0.06642

```python
class GeneratedPolicy(SymbolicPolicy):
    """
    Hypothesis 2 — Constraint-gradient controller with soft barriers and feedforward push.
    Phases:
      - Alignment and standoff: minimize lateral error e_perp, axial gap error e_along, maintain z offset via L2 terms.
      - Soft barrier: one-sided softplus to discourage being too far behind the desired contact point.
      - Push: feedforward velocity along goal direction, gated by alignment and barrier satisfaction.
      - Damping: velocity damping using tcp and a small share of object velocity for stability.
      - Gripper: proportional control to a reference opening g_ref (kept mostly closed for push).
    """
    def __init__(self, obs_dim, action_dim):
        super().__init__(obs_dim, action_dim)
        # Geometric/contact and vertical placement
        self.r_contact = nn.Parameter(torch.tensor(0.04))   # desired standoff to object along goal dir [m]
        self.z_push = nn.Parameter(torch.tensor(0.0))       # vertical offset above object [m]

        # Objective weights (positive)
        self.w_perp = nn.Parameter(torch.tensor(2.0))       # lateral error weight
        self.w_along = nn.Parameter(torch.tensor(1.5))      # axial error weight
        self.w_bar = nn.Parameter(torch.tensor(1.5))        # barrier weight
        self.w_z = nn.Parameter(torch.tensor(2.0))          # vertical error weight

        # Barrier softness and gradient step gain
        self.s = nn.Parameter(torch.tensor(0.02))           # softness (m)
        self.K = nn.Parameter(torch.tensor(0.5))            # step gain for gradient -> action

        # Feedforward push parameters
        self.v_set = nn.Parameter(torch.tensor(0.02))       # desired push speed (m/step)
        self.p_perp = nn.Parameter(torch.tensor(0.03))      # gate scale for lateral error (m)
        self.p_gap = nn.Parameter(torch.tensor(0.03))       # gate scale for barrier

        # Velocity damping
        self.kv_damp = nn.Parameter(torch.tensor(0.2))      # damping on tcp velocity

        # Gripper control (keep mostly closed for pushing)
        self.g_ref = nn.Parameter(torch.tensor(0.2))        # desired gripper opening fraction [0..1]
        self.kg = nn.Parameter(torch.tensor(2.0))           # proportional gain on gripper opening

        # Exploration noise (shared across action dims)
        self.log_std = nn.Parameter(torch.tensor(-1.0))

    def forward(self, obs):
        B = obs.shape[0]
        eps = 1e-8

        # Read required named fields
        tcp = self.obs_field(obs, "tcp")           # (B,3)
        prev_tcp = self.obs_field(obs, "prev_tcp") # (B,3)
        obj = self.obs_field(obs, "obj")           # (B,3)
        prev_obj = self.obs_field(obs, "prev_obj") # (B,3)
        goal = self.obs_field(obs, "goal")         # (B,3)
        gr = self.obs_field(obs, "gripper")        # (B,1)

        # Split planar and vertical components
        tcp_xy = tcp[:, 0:2]        # (B,2)
        obj_xy = obj[:, 0:2]        # (B,2)
        goal_xy = goal[:, 0:2]      # (B,2)
        tcp_z = tcp[:, 2:3]         # (B,1)
        obj_z = obj[:, 2:3]         # (B,1)

        # Velocities (unit time-step assumed; scale absorbed in gains)
        v_tcp_xy = tcp_xy - prev_tcp[:, 0:2]       # (B,2)
        v_obj_xy = obj_xy - prev_obj[:, 0:2]       # (B,2)

        # Direction towards goal in the plane
        diff_goal = goal_xy - obj_xy                                # (B,2)
        dist_goal = torch.norm(diff_goal, dim=-1, keepdim=True) + eps
        dir_goal = diff_goal / dist_goal                            # (B,2)
        # Perpendicular unit direction (90-degree rotation)
        dir_perp = torch.cat([-dir_goal[:, 1:2], dir_goal[:, 0:1]], dim=1)  # (B,2)

        # Contact reference point behind object along goal direction
        # target_contact_xy = obj_xy - r_contact * dir_goal
        # Axial and lateral errors
        delta_xy = tcp_xy - obj_xy                                   # (B,2)
        e_perp = torch.sum(delta_xy * dir_perp, dim=-1, keepdim=True)  # (B,1)
        # e_along = dot( tcp_xy - (obj_xy - r_contact * dir_goal), dir_goal )
        e_along = torch.sum((delta_xy + self.r_contact * dir_goal) * dir_goal, dim=-1, keepdim=True)  # (B,1)

        # One-sided barrier to discourage being too far behind desired contact
        s_pos = torch.abs(self.s) + 1e-6
        inv_s = 1.0 / s_pos
        B_gap = torch.log1p(torch.exp(-e_along * inv_s))  # softplus(-e_along / s)  -> (B,1)
        # dB/de_along = -sigmoid(-e_along / s) / s
        dB_de = -torch.sigmoid(-e_along * inv_s) * inv_s  # (B,1)

        # Vertical error
        z_tgt = obj_z + self.z_push                         # (B,1)
        e_z = tcp_z - z_tgt                                 # (B,1)

        # Positive weights/gains
        w_perp = torch.abs(self.w_perp) + 1e-8
        w_along = torch.abs(self.w_along) + 1e-8
        w_bar = torch.abs(self.w_bar) + 1e-8
        w_z = torch.abs(self.w_z) + 1e-8
        K = torch.abs(self.K) + 1e-8
        v_set = torch.abs(self.v_set) + 1e-8
        p_perp = torch.abs(self.p_perp) + 1e-8
        p_gap = torch.abs(self.p_gap) + 1e-8
        kv = torch.abs(self.kv_damp)  # allow zero damping

        # Gradient of L wrt tcp (planar)
        # L = w_perp * e_perp^2 + w_along * e_along^2 + w_bar * B_gap^2 + w_z * e_z^2
        # dL/dtcp_xy = 2*w_perp*e_perp*dir_perp + 2*w_along*e_along*dir_goal + 2*w_bar*B_gap*dB/de * dir_goal
        grad_xy = (
            2.0 * w_perp * e_perp * dir_perp
            + 2.0 * w_along * e_along * dir_goal
            + 2.0 * w_bar * B_gap * dB_de * dir_goal
        )  # (B,2)
        # Descent step in plane
        step_xy = -K * grad_xy  # (B,2)

        # Feedforward push, gated by alignment and barrier satisfaction
        gate_align = torch.abs(e_perp) / p_perp                      # (B,1)
        gate_gap = B_gap / p_gap                                     # (B,1)
        g_push = torch.sigmoid(-(gate_align + gate_gap))             # (B,1) in (0,1)
        push_ff = (g_push * v_set) * dir_goal                        # (B,2)

        # Damping on tcp velocity; include small damping on object vel for extra stability
        damp_xy = -kv * (v_tcp_xy + 0.5 * v_obj_xy)                  # (B,2)

        # Total planar command
        cmd_xy = step_xy + push_ff + damp_xy                         # (B,2)

        # Vertical descent step
        grad_z = 2.0 * w_z * e_z                                     # (B,1)
        cmd_z = -K * grad_z - kv * (tcp_z - prev_tcp[:, 2:3])        # (B,1)

        # Gripper proportional control towards reference opening
        g_ref_clamped = torch.clamp(self.g_ref, 0.0, 1.0)
        grip_cmd = self.kg * (g_ref_clamped - gr)                    # (B,1)

        # Concatenate to action mean (pre-tanh)
        mean = torch.cat([cmd_xy, cmd_z, grip_cmd], dim=1)           # (B,4)

        # Exploration std (positive)
        std = torch.exp(self.log_std) * torch.ones_like(mean)        # (B,4)

        # Optional diagnostics
        self.record_gate("push_gate", g_push.detach())
        self.record_gate("barrier", B_gap.detach())
        self.record_gate("align_err", torch.abs(e_perp).detach())

        return (mean, std)

    def get_param_ranges(self):
        return {
            "r_contact": (0.01, 0.08),
            "z_push": (-0.02, 0.05),
            "w_perp": (0.1, 20.0),
            "w_along": (0.1, 20.0),
            "w_bar": (0.1, 20.0),
            "w_z": (0.1, 20.0),
            "s": (0.005, 0.1),
            "K": (0.05, 5.0),
            "v_set": (0.005, 0.15),
            "p_perp": (0.005, 0.1),
            "p_gap": (0.005, 0.1),
            "kv_damp": (0.0, 2.0),
            "g_ref": (0.0, 1.0),
            "kg": (0.1, 10.0),
            "log_std": (-5.0, 0.0),
        }
```

#### Parent 2: gen0_cand2
  success 0.100 +- 0.056   mean return 65.6   over 30 cases
  failure labels: {'never_reached_object': 27, 'success': 3}
  final goal distance (m)    mean +0.1955   p25 +0.1760   p75 +0.2574
  signed goal progress (m)   mean +0.0257   p25 +0.0000   p75 +0.0236
  lateral drift (m)          mean +0.0023   p25 +0.0000   p75 +0.0004
  closest approach (m)       mean +0.0911   p25 +0.0752   p75 +0.1105
  object displacement (m)    mean +0.0264   p25 +0.0000   p75 +0.0256
  action saturation by axis: 0.00, 0.00, 0.00, 0.00
  gate occupancy above 0.5:
    approach             occupancy 1.000   transitions 0.0   crossed in 30/30 episodes
    blend                occupancy 1.000   transitions 0.0   crossed in 30/30 episodes
    contact              occupancy 0.000   transitions 0.0   crossed in 0/30 episodes
  parameters the executed action does NOT respond to: ['a_gap', 'a_perp', 'd_app', 'log_std']. These are dead weight; remove them or connect them to the action.
  before fitting: success 0.000, return 15.6. Fitting did not make it worse.
  fitting: train 0.14300 -> validation 0.14048

```python
class GeneratedPolicy(SymbolicPolicy):
    """
    Hypothesis 3 — Object-velocity servo with anisotropic alignment and contact gating.

    Phases and logic:
    - Pre-contact approach: Move the tcp toward a precontact point behind the object along the goal direction.
      A smooth approach gate g_app increases with distance to that point.
    - Contact gating: A smooth contact gate g_c increases (to ~0.5) as the tcp aligns behind the object (small e_gap, e_perp).
      The overall blend is g = g_c + (1 - g_c) * g_app, so far from contact the approach dominates; near alignment, velocity
      servo terms are active but scaled by g_c.
    - Velocity servo on object: Regulate object velocity along the goal direction using v_des - (v_obj projected on goal dir).
      Correct along-track gap and lateral misalignment with separate gains (anisotropic alignment).
    - Height control: PD tracking of z_target = obj.z + z_push.
    - Gripper control: Servo gripper to g_ref with gain kg (closed for pushing).
    """
    def __init__(self, obs_dim, action_dim):
        super().__init__(obs_dim, action_dim)
        # Desired object velocity shaping
        self.v_max = nn.Parameter(torch.tensor(0.10))        # m/step (scaled by env), low initial
        self.k_d = nn.Parameter(torch.tensor(2.0))           # shaping of tanh on goal error

        # Geometry / alignment and object-velocity feedback
        self.r_contact = nn.Parameter(torch.tensor(0.04))    # standoff behind object [m]
        self.k_vo = nn.Parameter(torch.tensor(0.5))          # gain on (v_des - v_obj_proj)
        self.k_pos_along = nn.Parameter(torch.tensor(1.0))   # gain along goal direction (gap)
        self.k_pos_perp = nn.Parameter(torch.tensor(1.5))    # gain on lateral error
        self.kv = nn.Parameter(torch.tensor(0.2))            # tcp velocity damping in xy

        # Contact gating and approach shaping
        self.a_perp = nn.Parameter(torch.tensor(0.03))       # scale for lateral alignment error in gate
        self.a_gap = nn.Parameter(torch.tensor(0.03))        # scale for gap error in gate
        self.d_app = nn.Parameter(torch.tensor(0.03))        # approach distance threshold
        self.t_app = nn.Parameter(torch.tensor(0.05))        # approach transition sharpness (distance scale)

        # Height control
        self.z_push = nn.Parameter(torch.tensor(0.01))       # offset above object's z
        self.kp_z = nn.Parameter(torch.tensor(3.0))          # proportional gain on z
        self.kv_z = nn.Parameter(torch.tensor(0.5))          # damping on z velocity

        # Gripper control (drive toward closed for pushing)
        self.g_ref = nn.Parameter(torch.tensor(-0.5))        # desired gripper opening (closed < 0)
        self.kg = nn.Parameter(torch.tensor(1.0))            # gain for gripper servo

        # Exploration noise (log scale)
        self.log_std = nn.Parameter(torch.tensor(-1.0))

    def forward(self, obs):
        # Read required observation fields by NAME
        tcp = self.obs_field(obs, "tcp")            # (B,3)
        prev_tcp = self.obs_field(obs, "prev_tcp")  # (B,3)
        obj = self.obs_field(obs, "obj")            # (B,3)
        prev_obj = self.obs_field(obs, "prev_obj")  # (B,3)
        goal = self.obs_field(obs, "goal")          # (B,3)
        gripper = self.obs_field(obs, "gripper")    # (B,1)

        B = obs.shape[0]
        eps = 1e-8

        # XY slices for planar push
        tcp_xy = tcp[:, 0:2]
        prev_tcp_xy = prev_tcp[:, 0:2]
        obj_xy = obj[:, 0:2]
        prev_obj_xy = prev_obj[:, 0:2]
        goal_xy = goal[:, 0:2]

        # Velocities (finite difference)
        v_tcp_xy = tcp_xy - prev_tcp_xy
        v_obj_xy = obj_xy - prev_obj_xy

        # Goal direction and its perpendicular
        diff_goal_xy = goal_xy - obj_xy
        diff_norm = torch.norm(diff_goal_xy, dim=-1, keepdim=True) + eps
        dir_to_goal = diff_goal_xy / diff_norm  # (B,2)
        dir_perp = torch.cat([-dir_to_goal[:, 1:2], dir_to_goal[:, 0:1]], dim=1)  # 90-deg CCW

        # Desired object velocity (elementwise tanh shaping, saturates at v_max)
        v_des_xy = self.v_max * torch.tanh(self.k_d * diff_goal_xy)

        # Project object velocity onto goal direction
        v_obj_along = torch.sum(v_obj_xy * dir_to_goal, dim=-1, keepdim=True)  # (B,1)
        v_obj_proj = v_obj_along * dir_to_goal  # (B,2)

        # Alignment errors
        # Lateral misalignment: signed distance along dir_perp from tcp to object center
        e_perp = torch.sum((tcp_xy - obj_xy) * dir_perp, dim=-1, keepdim=True)  # (B,1)
        # Gap along goal direction to precontact point behind object
        precontact_xy = obj_xy - self.r_contact * dir_to_goal
        e_gap = torch.sum((tcp_xy - precontact_xy) * dir_to_goal, dim=-1, keepdim=True)  # (B,1)

        # Smooth contact gate: higher near good alignment (small e_perp and e_gap)
        gate_sum = torch.abs(e_perp) / (self.a_perp + eps) + torch.abs(e_gap) / (self.a_gap + eps)
        g_c = torch.sigmoid(-gate_sum)  # in (0, 0.5]; 0.5 at perfect alignment
        self.record_gate("contact", g_c)

        # Approach gate to precontact point
        dist_to_precontact = torch.norm(tcp_xy - precontact_xy, dim=-1, keepdim=True)  # (B,1)
        g_app = torch.sigmoid((dist_to_precontact - self.d_app) / (self.t_app + eps))
        self.record_gate("approach", g_app)

        # Blend between approach and contact regulation
        g_blend = g_c + (1.0 - g_c) * g_app  # (B,1)
        self.record_gate("blend", g_blend)

        # Object-velocity servo + anisotropic alignment + tcp damping
        u_xy_raw = (
            self.k_vo * (v_des_xy - v_obj_proj)
            + self.k_pos_along * e_gap * dir_to_goal
            - self.k_pos_perp * e_perp * dir_perp
            - self.kv * v_tcp_xy
        )
        u_xy = u_xy_raw * g_blend  # (B,2)

        # Height control (PD) tracking z_target = obj.z + z_push
        tcp_z = tcp[:, 2:3]
        prev_tcp_z = prev_tcp[:, 2:3]
        v_tcp_z = tcp_z - prev_tcp_z
        z_target = obj[:, 2:3] + self.z_push
        u_z = self.kp_z * (z_target - tcp_z) - self.kv_z * v_tcp_z  # (B,1)

        # Gripper: servo toward g_ref
        g_ref_b = self.g_ref.unsqueeze(0).expand(B, 1)
        u_grip = self.kg * (g_ref_b - gripper)  # (B,1)

        # Concatenate to form action mean
        mean = torch.cat([u_xy, u_z, u_grip], dim=1)  # (B,4)

        # Exploration std (positive)
        std = torch.exp(self.log_std).unsqueeze(0).expand(B, 1) * torch.ones_like(mean)

        return (mean, std)

    def get_param_ranges(self):
        return {
            "v_max": (0.02, 0.5),
            "k_d": (0.5, 10.0),
            "r_contact": (0.01, 0.15),
            "k_vo": (0.1, 5.0),
            "k_pos_along": (0.1, 8.0),
            "k_pos_perp": (0.1, 12.0),
            "kv": (0.0, 2.0),
            "a_perp": (0.005, 0.2),
            "a_gap": (0.005, 0.2),
            "d_app": (0.005, 0.2),
            "t_app": (0.005, 0.2),
            "z_push": (-0.02, 0.05),
            "kp_z": (0.1, 15.0),
            "kv_z": (0.0, 5.0),
            "g_ref": (-1.0, 1.0),
            "kg": (0.1, 10.0),
            "log_std": (-5.0, 0.0),
        }
```

### Diagnostics for the remaining candidates

#### gen0_cand0
  success 0.167 +- 0.069   mean return 81.2   over 30 cases
  failure labels: {'never_reached_object': 18, 'stopped_short_of_goal': 7, 'success': 5}
  final goal distance (m)    mean +0.1582   p25 +0.0820   p75 +0.2221
  signed goal progress (m)   mean +0.0629   p25 +0.0000   p75 +0.1437
  lateral drift (m)          mean +0.0141   p25 +0.0000   p75 +0.0181
  closest approach (m)       mean +0.0533   p25 +0.0386   p75 +0.0602
  object displacement (m)    mean +0.0687   p25 +0.0000   p75 +0.1447
  action saturation by axis: 0.00, 0.00, 0.00, 0.00
  gate occupancy above 0.5:
    g_approach           occupancy 0.007   transitions 0.3   crossed in 5/30 episodes
    g_contact            occupancy 0.000   transitions 0.0   crossed in 0/30 episodes
    g_push               occupancy 0.980   transitions 0.5666666666666667   crossed in 30/30 episodes
  parameters the executed action does NOT respond to: ['log_std']. These are dead weight; remove them or connect them to the action.
  before fitting: success 0.100, return 74.6. Fitting did not make it worse.
  fitting: train 0.07280 -> validation 0.07164

### Archive
Retained across all generations so far: the most robust, the simplest competitive, and the most behaviourally distinct candidate.
slot      candidate           success  progress  params  failures
------------------------------------------------------------------------------
robust    gen0_cand1            0.200    0.1053      15  stopped_short_of_goal
simplest  gen0_cand0            0.200    0.0436      15  never_reached_object
distinct  gen0_cand2            0.100    0.0276      17  never_reached_object

### History
  generation 0: 3 valid, 0 invalid, best success 0.267

### How to read this
Note: across 144 fitted configurations on this task, behavioural-cloning validation loss correlated with development success at Pearson +0.19 (p=0.023). That is the wrong sign: a better fit to the expert did not give a better controller. Treat the loss as context, not as evidence of quality.
Success is the outcome that matters. When every candidate scores zero, signed goal progress is the discriminating measure: positive means the object ended closer to the goal than it started, negative means the controller pushed it away. `never_reached_object` and `pushed_away_from_goal` are different faults and need different repairs.