"""Map development success against behavioural-cloning budget.

The control showed plain regression at 1000 steps reproducing the residual-scale
result exactly, which means residual scale contributes nothing: stage two fits
only the scale, and deterministic execution ignores the scale. The gain was the
halved mean-fitting budget.

If that is right, success is non-monotonic in the number of gradient steps while
validation loss falls monotonically. This maps both curves over three seeds so
the peak is not one seed's luck.
"""

import json
import sys

sys.path.insert(0, "/home/ubuntu/LaRes")

import numpy as np

from lares.core.obs_schema import get_obs_schema
from lares.core.training_pipeline import DemoBuffer, ensure_mujoco_headless_gl
from lares.eval import (
    EvaluationManifest,
    PolicyActor,
    evaluate_manifest,
    make_manifest_env,
)
from lares.fitting import DETERMINISTIC_MSE, load_bank, prepare_data
from lares.fitting.optimizers import fit_with_objective

BUDGETS = (250, 500, 750, 1000, 1250, 1500, 2000, 3000)
SEEDS = (0, 1, 2)

ensure_mujoco_headless_gl()
schema = get_obs_schema("push-v2")
buf = DemoBuffer.load("/home/ubuntu/LaRes/logs/baseline_lock/demo_push-v2.pkl")
data = prepare_data(buf, split_seed=0)
dev = EvaluationManifest.load(
    "/home/ubuntu/LaRes/config/manifests/push-v2_development.yaml"
)
env = make_manifest_env(dev, dev.resolve_pool(), 200)
structures = [
    s for s in load_bank(family="simple")
    if s.structure_id in ("simple_reach_push", "simple_damped_push")
]

rows = []
for struct in structures:
    print(f"\n{struct.structure_id}")
    print(f"{'budget':>8}{'success mean':>14}{'success sd':>12}{'val loss':>11}")
    print("-" * 45)
    for budget in BUDGETS:
        successes, losses = [], []
        for seed in SEEDS:
            r = fit_with_objective(
                struct, data, DETERMINISTIC_MSE, budget=budget, batch_size=256,
                seed=seed, schema=schema,
            )
            p = struct.build(schema)
            p.load_state_dict(r.final_state)
            res = evaluate_manifest(
                PolicyActor(p, True, name=f"b{budget}s{seed}"), dev, env, max_steps=150
            )
            successes.append(res.success_rate)
            losses.append(r.validation_loss_final)
            rows.append(
                {
                    "structure_id": struct.structure_id,
                    "budget": budget,
                    "seed": seed,
                    "success_rate": res.success_rate,
                    "mean_return": res.mean_reward,
                    "validation_loss": r.validation_loss_final,
                }
            )
        print(f"{budget:>8}{np.mean(successes):>14.3f}{np.std(successes):>12.3f}"
              f"{np.mean(losses):>11.5f}")

with open(
    "/home/ubuntu/LaRes/logs/objective_comparison/budget_sweep.json", "w", encoding="utf-8"
) as f:
    json.dump({"budgets": list(BUDGETS), "seeds": list(SEEDS), "rows": rows}, f, indent=2)
print("\nwrote logs/objective_comparison/budget_sweep.json")
env.close()
