# Provenance of the files added for review

## Checkpoint (BC budget) sweep
- Data: `logs/objective_comparison/budget_sweep.json`
  2 structures (simple_reach_push, simple_damped_push) x 8 budgets (250..3000) x 3 seeds,
  deterministic MSE, batch 256, all 50 development cases, 150-step horizon.
  Per-row fields: structure_id, budget, seed, success_rate, mean_return, validation_loss.
- Script: `recovered/budget_sweep.py`. Never committed. It was an ad-hoc scratchpad script
  from the 2026-09-09 session, since deleted. Recovered verbatim from that session's
  transcript: written once at 17:33 UTC, never edited, run once. Its printed table matches
  the JSON and the table in RESEARCH_HANDOFF.md.

## Evidence block and experiment record
- Produced by a short live evolution run on 2026-09-13 (843 s), config in
  `recovered/review_run.yaml`: production settings (gpt-5, two-phase per_idea, bc_steps 2000
  with 4 rollout probes, screen 10 / expanded 30, 150-step horizon), shrunk to
  2 generations x 3 candidates, reusing logs/baseline_lock/demo_push-v2.pkl.
- `logs/evolution_review_20260913/gen_0/feedback.md`: the evidence block generation 0 wrote.
  It was actually sent to generation 1's prompts (present in llm_evolution_transcript.log).
- `logs/evolution_review_20260913/experiments/gen0_cand1.json`: the record for Parent 1 of
  that block, the promoted incumbent (screen 0.200 on 10 cases, expanded 0.267 on 30).
  The archive table in feedback.md shows the screen figure, and the population table shows
  the expanded one.
- Run outcome: gen 0 best success 0.267. All three gen 1 candidates scored 0.000; paired against
  gen0_cand1: -0.267, 95% CI [-0.428, -0.106]. Scripted expert on the same 30 cases: 1.00.
- Known gap: gen 1 records have empty parent_ids, idea_id and proposal_id, although gen 1
  was generated from this feedback block. Lineage is not recorded.
